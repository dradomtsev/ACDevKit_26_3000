
#include "ElementIterator.hpp"

GSAPI::ElementIterator::~ElementIterator ()
{}
