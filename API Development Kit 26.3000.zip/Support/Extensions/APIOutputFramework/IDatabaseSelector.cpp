
#include "IDatabaseSelector.hpp"

GSAPI::IDatabaseSelector::~IDatabaseSelector ()
{}
