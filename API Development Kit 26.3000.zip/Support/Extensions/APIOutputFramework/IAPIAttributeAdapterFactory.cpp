
#include "IAPIAttributeAdapterFactory.hpp"

GSAPI::IAPIAttributeAdapterFactory::~IAPIAttributeAdapterFactory ()
{}
