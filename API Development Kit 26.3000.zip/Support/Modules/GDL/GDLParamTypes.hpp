#ifndef GDLPARAMTYPES_HPP
#define GDLPARAMTYPES_HPP

#pragma once

namespace GDL
{
	class ParameterGetter;
	class ParameterAccessor;
	class Parameters;
}

#endif