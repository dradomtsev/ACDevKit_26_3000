#ifndef GEOM_PPE_OPERATIONRETURNSTATUS_HPP
#define GEOM_PPE_OPERATIONRETURNSTATUS_HPP
#pragma once

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
enum class OperationReturnStatus
{
	Successful,
	Failed,
	Undefined
};
#endif //GEOM_PPE_OPERATIONRETURNSTATUS_HPP
